# Grinny<br><br>

A Dynamic website template that was built to be reused on any type/design that a client may need

**Technologies Used,**<br>
Front-End: HTML5, CSS3, Bootstrap 5<br>
Back-End: PHP<br>
Database: SQL<br><br>

**Features**<br>
8 Static web pages,<br>
User registration & session creation,<br>
Basic CRUD functions<br><br>
